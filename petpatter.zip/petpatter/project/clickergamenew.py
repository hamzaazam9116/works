import turtle
import tkinter as tk
import sqlite3

# Create a SQLite database and table to store user details
conn = sqlite3.connect('user_details.db')
c = conn.cursor()
c.execute('''CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT,
                email TEXT,
                clicks INTEGER
            )''')
conn.commit()


# Function to save user details to the database
def save_user_details(name, email, clicks):
    c.execute("INSERT INTO users (name, email, clicks) VALUES (?, ?, ?)", (name, email, clicks))
    conn.commit()

# list of animals
animalImages = ["catgif.gif", "huskey.gif", "rabbit.gif"]

# keep track of current animal index
currentAnimalIndex = 0

# Create the turtle screen
wn = turtle.Screen()
wn.title("Cat Clicker!")
wn.bgcolor("black")

wn.register_shape("catgif.gif")

cookie = turtle.Turtle()
cookie.shape("catgif.gif")
cookie.speed(0)

clicks = 0

counter_pen = turtle.Turtle()
counter_pen.hideturtle()
counter_pen.color("white")
counter_pen.penup()
counter_pen.goto(0, 250)
counter_pen.write(f"Clicks: {clicks}", align="center", font=("Courier New", 32, "normal"))

message_pen = turtle.Turtle()
message_pen.hideturtle()
message_pen.color("white")
message_pen.penup()
message_pen.goto(0, -250)


# Function to handle click event
def clicked(x, y):
    global clicks, currentAnimalIndex
    clicks += 1
    counter_pen.clear()
    counter_pen.write(f"Clicks: {clicks}", align="center", font=("Courier New", 32, "normal"))

    # Check if the user has reached the desired number of clicks for a discount
    if clicks == 10:
        show_discount_form()
    elif clicks > 10:
        message_pen.clear()
        message_pen.write("Congratulations! You've received a discount!", align="center",
                          font=("Courier New", 24, "normal"))

    if clicks % 10 == 0:
        currentAnimalIndex = (currentAnimalIndex + 1) % len(animalImages)
        new_image = animalImages[currentAnimalIndex]
        wn.register_shape(new_image)
        cookie.shape(new_image)



cookie.onclick(clicked)


def show_discount_form():
    # Create a Tkinter window for the discount form
    form_window = tk.Toplevel()
    form_window.title("Discount Form")

    # Create and position form elements
    name_label = tk.Label(form_window, text="Name:")
    name_label.pack()
    name_entry = tk.Entry(form_window)
    name_entry.pack()

    email_label = tk.Label(form_window, text="Email:")
    email_label.pack()
    email_entry = tk.Entry(form_window)
    email_entry.pack()

    # Function to save user details and close the form
    def save_details():
        name = name_entry.get()
        email = email_entry.get()
        save_user_details(name, email, clicks)
        form_window.destroy()

    save_button = tk.Button(form_window, text="Save", command=save_details)
    save_button.pack()


def close_window():
    # Close the database connection before closing the program
    conn.close()
    wn.bye()


# Add an exit button to the turtle screen
exit_button = turtle.Turtle()
exit_button.hideturtle()
exit_button.penup()
exit_button.goto(300, 250)
exit_button.write("Exit", align="center", font=("Courier New", 16, "normal"))
exit_button.onclick(close_window)

wn.mainloop()