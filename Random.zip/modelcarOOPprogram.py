class Car:
    def __init__(self, make, model, year, speed=0):
        self.__make = make
        self.__model = model
        self.__year = year
        self.__speed = speed
        
    def accelerate(self):
        self.__speed += 5
        
    def brake(self):
        if self.__speed >=5:
            self.__speed -=5
        else:
            self.__speed =0
            
    def get_speed(self):
        return self.__speed
    
    def get_make(self):
        return self.__make
    
    def get_model(self):
        return self.__model
    
    def get_year(self):
        return self.__year
        
my_car = Car("Toyota", "Corolla", 2020)
print(my_car.get_make())
print(my_car.get_model())
print(my_car.get_year())

my_car.accelerate()
my_car.accelerate()
print(my_car.get_speed()) # prints 10

my_car.brake()
print(my_car.get_speed()) # prints 5
