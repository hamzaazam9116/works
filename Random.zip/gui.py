from tkinter import *
def calculatewages():
    hours = float(nhours.get())

    hsal=float(salaryh.get())
    salary = hsal*hours
    labelresult = Label(myGUI, text="your salary is: £ %.2f" % salary).grid(row=7, column=2)
    return


myGUI=Tk()
myGUI.geometry('400x200+100+200')
myGUI.title('Wages Calculator')

salaryh=StringVar()
nhours=StringVar()

label1=Label(myGUI, text='Welcome to the wages Calculator', fg='red').grid(row=0,column=2)
label2=Label(myGUI, text='Enter hourly rate').grid(row=1,column=0)
label3=Label(myGUI, text='Number of hours').grid(row=2, column=0)


mysalaryh=Entry(myGUI, textvariable=salaryh).grid(row=1,column=2)
myhours=Entry(myGUI, textvariable=nhours).grid(row=2, column=2)

button1=Button(myGUI, text='Calculate wages', command=calculatewages).grid(row=3,column=0)

myGUI.mainloop()